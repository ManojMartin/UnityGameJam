﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enimmove2 : MonoBehaviour
{
    Rigidbody rb;
    [SerializeField] float enimforce;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    
    void Update()
    {


        rb.AddForce(0f, 0f, -enimforce);

    }
}
