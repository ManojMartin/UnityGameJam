﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collectible : MonoBehaviour
{
    private void OnCollisionEnter(Collision col1)
    {
        if (col1.gameObject.tag == "Player")
        {
            Debug.Log("collided with player");
            Destroy(this.gameObject);
        }
    }
}
