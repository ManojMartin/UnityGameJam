﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enimmove : MonoBehaviour
{
    Rigidbody rb;
    [SerializeField] float enimforce;
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.AddForce(enimforce, 0f, 0f);

        
    }
}

