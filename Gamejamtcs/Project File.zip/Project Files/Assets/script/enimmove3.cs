﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enimmove3 : MonoBehaviour
{
    Rigidbody rb;
    [SerializeField] float enimforce;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    
    void Update()
    {


        rb.AddForce(-enimforce,0f, 0f);

    }
}
