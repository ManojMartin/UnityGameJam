﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{
    [SerializeField]
    string _movementX;
   
    [SerializeField]
    string _movementZ;

    [SerializeField]
    float _speed;

    [SerializeField]
    float torque;

    Rigidbody _rigidBody;
    float _moveX;
    float _moveZ;

    private AudioSource audi;
    void Start()
    {
        _rigidBody = this.GetComponent<Rigidbody>();

        audi = GetComponent<AudioSource>();
        
    }
    
    void Update()
    {
        _moveX = Input.GetAxis(_movementX);
        _moveZ = Input.GetAxis(_movementZ);
    }

    void FixedUpdate()
    {
        if (_rigidBody != null)
        {
            Vector3 moveVector = new Vector3(_moveX, 0, _moveZ) * _speed*Time.deltaTime;
            _rigidBody.AddForce(moveVector, ForceMode.Acceleration);
            float turn = Input.GetAxis("Horizontal");
            _rigidBody.AddTorque(transform.up * torque * turn);
        }
    }
    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "walls")
        {
            audi.Play();

        }
    }


}