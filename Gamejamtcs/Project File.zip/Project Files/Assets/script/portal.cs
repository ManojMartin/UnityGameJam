﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class portal : MonoBehaviour
{ 
    public AudioSource audi;
void Start()
{
    audi = GetComponent<AudioSource>();

}

    private void Update()
    {
        Scene scene = SceneManager.GetActiveScene();

        

    }
    public void OnCollisionEnter(Collision col1)
    {
        if (col1.gameObject.tag == "Player")
        {
            SceneManager.LoadScene("level2");
            audi.Play();
        }
    }
}
