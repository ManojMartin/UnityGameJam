﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class soundsi : MonoBehaviour
{
    private AudioSource audi;

    void Start()
    {
        audi = GetComponent<AudioSource>();
    }


    public void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag=="player")
        {
            audi.Play();

        }
    }
}
