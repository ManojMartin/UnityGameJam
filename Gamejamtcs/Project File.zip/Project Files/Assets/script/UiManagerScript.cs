﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UiManagerScript : MonoBehaviour
{
    public GameObject Panel;

    public void Awake()
    {
        Panel.SetActive(false);
    }
    private void Update()
    {
        Scene scene = SceneManager.GetActiveScene();

        if (Input.GetKeyDown(KeyCode.Escape) && scene.name != "pointless_Survival")
        {
            MainMenu();
        }
        else if(Input.GetKeyDown(KeyCode.Escape) && scene.name == "GameMain")
        {

            Panel.SetActive(true);
        }

    }




    public void Play()
    {

        SceneManager.LoadScene("level1");
    }
    public void Exit()
    {
        Application.Quit();
    }
    public void control()
    {
        SceneManager.LoadScene("rule");
    }
    public void Info()
    {
        SceneManager.LoadScene("Info");
    }

    public void MainMenu()
    {

        SceneManager.LoadScene("start");
    }
    public void Restart()
    {

        SceneManager.LoadScene("level1");
    }
    public void Restart2()
    {

        SceneManager.LoadScene("level2");
    }
    public void Restart3()
    {

        SceneManager.LoadScene("level3");
    }



    public void PanelClose()
    {
        Panel.SetActive(true);
    }

}

