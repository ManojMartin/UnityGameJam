﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class collision : MonoBehaviour
{
    public AudioSource audi;
    void Start()
    {
        audi = GetComponent<AudioSource>();

    }
    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "walls")
        {
            audi.Play();
        }
            if (col.gameObject.tag == "Player")
        {
            Debug.Log("collided");
            Destroy(col.gameObject);
           
            SceneManager.LoadScene("esc");
           
        }
    }
}
